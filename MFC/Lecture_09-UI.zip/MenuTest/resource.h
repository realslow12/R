//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// MenuTest.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define ID_INDICATOR_POS                103
#define IDR_MAINFRAME                   128
#define IDR_MenuTestTYPE                129
#define ID_INDICATOR_HA                 130
#define ID_COLOR_RED                    32771
#define ID_COLOR_GREEN                  32772
#define ID_COLOR_BLUE                   32773
#define ID_SELECT_RECTANGLE             32777
#define ID_SELECT_CIRCLE                32778
#define AFX_IDS_APP_TITLE               0xE000
#define AFX_IDS_IDLEMESSAGE             0xE001
#define ID_EDIT_CLEAR                   0xE120
#define ID_EDIT_CLEAR_ALL               0xE121
#define ID_EDIT_FIND                    0xE124
#define ID_EDIT_REPEAT                  0xE128
#define ID_EDIT_REPLACE                 0xE129
#define ID_EDIT_SELECT_ALL              0xE12A
#define ID_EDIT_REDO                    0xE12C
#define ID_WINDOW_SPLIT                 0xE135
#define ID_INDICATOR_EXT                0xE700
#define ID_INDICATOR_CAPS               0xE701
#define ID_INDICATOR_NUM                0xE702
#define ID_INDICATOR_SCRL               0xE703
#define ID_INDICATOR_OVR                0xE704
#define ID_INDICATOR_REC                0xE705
#define AFX_IDS_SCSIZE                  0xEF00
#define AFX_IDS_SCMOVE                  0xEF01
#define AFX_IDS_SCMINIMIZE              0xEF02
#define AFX_IDS_SCMAXIMIZE              0xEF03
#define AFX_IDS_SCNEXTWINDOW            0xEF04
#define AFX_IDS_SCPREVWINDOW            0xEF05
#define AFX_IDS_SCCLOSE                 0xEF06
#define AFX_IDS_SCRESTORE               0xEF12
#define AFX_IDS_SCTASKLIST              0xEF13

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
