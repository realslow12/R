# COMP1500StarterPack
Starter pack for COMP1500
